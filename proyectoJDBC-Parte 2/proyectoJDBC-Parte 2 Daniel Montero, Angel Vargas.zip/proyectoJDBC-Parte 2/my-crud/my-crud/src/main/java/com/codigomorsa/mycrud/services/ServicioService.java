package com.codigomorsa.mycrud.services;

import com.codigomorsa.mycrud.model.Servicio;
import com.codigomorsa.mycrud.model.Vehiculo;
import com.codigomorsa.mycrud.repositories.ServicioRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioService {
    private final ServicioRepository repository;

    public ServicioService(ServicioRepository repository){
        this.repository = repository;
    }

    public List<Servicio> getAllServicio(){
        return repository.getAllServicio();
    }


    public long createCierreServicio(Servicio newServicio, long idServicio){
        return repository.createCierreServicio(newServicio, idServicio);
    }
    
    public Servicio getServicioById(long id) {
        return repository.getServicioById(id);
    }

    
    public ResponseEntity<String> createServicioPlaca(Servicio newServicioP){
        return repository.createServicioPlaca(newServicioP);
    }

}
