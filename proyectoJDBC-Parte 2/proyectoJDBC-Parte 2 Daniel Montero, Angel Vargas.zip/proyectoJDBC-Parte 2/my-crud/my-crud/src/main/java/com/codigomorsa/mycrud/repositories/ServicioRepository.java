package com.codigomorsa.mycrud.repositories;

import com.codigomorsa.mycrud.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Repository
public class ServicioRepository {
    private final NamedParameterJdbcTemplate jdbcTemplate;

    

    @Autowired
    private VehiculoRepository vehiculoRepository;

    public ClienteRepository clienteRepository;


    private final ServicioMapper mapper = new ServicioMapper();
    

    private final RowMapper<Vehiculo> Vmapper = new VehiculoMapper();

    
    private final RowMapper<Cliente> Cmapper = new ClienteMapper();

    private final RowMapper<Piezas_Compradas> Pmapper = new PiezasCompradasMapper();


    private static class ClienteMapper implements RowMapper<Cliente> {
        @Override
        public Cliente mapRow(ResultSet sr, int rowNum) throws SQLException {

            long id = sr.getInt("id");
            int numero_cliente = sr.getInt("numero_cliente");
            int cedula = sr.getInt("cedula");
            String tipoCedula = sr.getString("tipo_cedula");
            int telefono = sr.getInt("telefono");
            String email = sr.getNString("email");
            int taller = sr.getInt("taller");

            return new Cliente(id, numero_cliente, cedula, tipoCedula, telefono, email, taller);


        }
    }

    private static class VehiculoMapper implements RowMapper<Vehiculo> {
        @Override
        public Vehiculo mapRow(ResultSet sr, int rowNum) throws SQLException {

            String numeroPlaca = sr.getString("numero_placa");
            String marca = sr.getNString("marca");
            String modelo = sr.getNString("modelo");
            Date anoFabricacion = sr.getDate("año_fabricacion");
            String VIN = sr.getNString("VIN");
            int cliente = sr.getInt("cliente");



            return new Vehiculo(numeroPlaca, marca, modelo, anoFabricacion, VIN, cliente);


        }
    }

    private static class PiezasCompradasMapper implements RowMapper<Piezas_Compradas> {
        @Override
        public Piezas_Compradas mapRow(ResultSet sr, int rowNum) throws SQLException {

            long id = sr.getInt("id");
            String codigo = sr.getNString("codigo");
            int cantidad = sr.getInt("cantidad");
            int costoTotal = sr.getInt("costo_total");
            String pieza = sr.getString("codigo_pieza");
            int servicio = sr.getInt("servicio");
            return new Piezas_Compradas(id, codigo, cantidad, costoTotal, pieza, servicio);


        }
    }






    

    public ServicioRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate, DataSource dataSource){
        this.jdbcTemplate = namedParameterJdbcTemplate;
        
    }

    public List<Servicio> getAllServicio(){
        String sql = "select * from servicio";
        return jdbcTemplate.query(sql, mapper);
    }



    public Servicio getServicioById(long id) {
        String sql = "SELECT s.*, c.* FROM servicio s " +
                "JOIN vehiculo v ON s.vehiculo_placa = v.numero_placa " +
                "JOIN cliente c ON v.cliente = c.id " +
                "WHERE s.id = :id";

        Map<String, Object> parameters = Collections.singletonMap("id", id);
        Servicio servicio = jdbcTemplate.queryForObject(sql, parameters, new ServicioMapper());

        // Obtener la información del vehículo relacionado
        String sqlVehiculo = "SELECT v.* FROM vehiculo v WHERE v.numero_placa = :numero_placa";
        Map<String, Object> vehiculoParameters = Collections.singletonMap("numero_placa", servicio.getVehiculo_placa());
        Vehiculo vehiculo = jdbcTemplate.queryForObject(sqlVehiculo, vehiculoParameters, Vmapper);

        // Obtener la información del cliente relacionado
        String sqlCliente = "SELECT c.* FROM cliente c WHERE c.id = :clienteId";
        Map<String, Object> clienteParameters = Collections.singletonMap("clienteId", vehiculo.getCliente());
        Cliente cliente = jdbcTemplate.queryForObject(sqlCliente, clienteParameters, Cmapper);

        // Obtener la información de las piezas compradas relacionadas con el servicio
        String sqlPiezasCompradas = "SELECT pc.* FROM piezas_compradas pc WHERE pc.servicio = :servicioId";
        Map<String, Object> piezasCompradasParameters = Collections.singletonMap("servicioId", id);
        List<Piezas_Compradas> piezasCompradasList = jdbcTemplate.query(sqlPiezasCompradas, piezasCompradasParameters, Pmapper);

        // Configurar la lista de vehículos, clientes y piezas compradas en el servicio
        servicio.setVehiculoList(Collections.singletonList(vehiculo));
        servicio.setClienteList(Collections.singletonList(cliente));
        servicio.setPiezasCompradasList(piezasCompradasList);

        return servicio;
    }

    public ResponseEntity<String> createServicioPlaca(Servicio newServicio) {
        String sql = "INSERT INTO servicio (fecha_ingreso, fecha_conclusion, descripcion, horas_invertidas, costo_total_mano_de_obra, costo_total_facturado, porcentaje_utilidad, vehiculo_placa) " +
                "VALUES (:fecha_ingreso, :fecha_conclusion, :descripcion, :horas_invertidas, :costo_total_mano_de_obra, :costo_total_facturado, :porcentaje_utilidad, :vehiculo_placa)";

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fecha_ingreso", newServicio.getFecha_ingreso());
        parameters.put("fecha_conclusion", newServicio.getFecha_conclusion());
        parameters.put("descripcion", newServicio.getDescripcion());
        parameters.put("horas_invertidas", newServicio.getHoras_invertidas());
        parameters.put("costo_total_mano_de_obra", newServicio.getCosto_total_mano_de_obra());
        parameters.put("costo_total_facturado", newServicio.getCosto_total_facturado());
        parameters.put("porcentaje_utilidad", newServicio.getPorcentaje_utilidad());
        parameters.put("vehiculo_placa", newServicio.getVehiculo_placa());

        try {
            // Validar que el número de placa del vehículo existe
            if (!vehiculoRepository.existsByPlaca(newServicio.getVehiculo_placa())) {
                throw new RuntimeException("El número de placa del vehículo no existe");
            }

            jdbcTemplate.update(sql, parameters);
            return new ResponseEntity<>("Servicio creado exitosamente", HttpStatus.CREATED);
        } catch (RuntimeException e) {
            e.printStackTrace(); // Imprime la excepción en la consola
            return new ResponseEntity<>("El número de placa del vehículo no existe", HttpStatus.BAD_REQUEST);
        }
    }



    public long createCierreServicio(Servicio newServicioCierreServicio, long idServicio) {
        String sql = "UPDATE SERVICIO " +
                "SET fecha_conclusion = :fecha_conclusion, " +
                "descripcion = :descripcion," +
                "horas_invertidas = :horas_invertidas, " +
                "costo_total_mano_de_obra = :costo_total_mano_de_obra, " +
                "costo_total_facturado = :costo_total_facturado, " +
                "porcentaje_utilidad = :porcentaje_utilidad " +
                "WHERE id = :idServicio";  
    
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fecha_conclusion", newServicioCierreServicio.getFecha_conclusion());
        parameters.put("descripcion", newServicioCierreServicio.getDescripcion());
        parameters.put("horas_invertidas", newServicioCierreServicio.getHoras_invertidas());
        parameters.put("costo_total_mano_de_obra", newServicioCierreServicio.getCosto_total_mano_de_obra());
        parameters.put("costo_total_facturado", newServicioCierreServicio.getCosto_total_facturado());
        parameters.put("porcentaje_utilidad", newServicioCierreServicio.getPorcentaje_utilidad());
        parameters.put("idServicio", idServicio);
    
        int rowsUpdated = jdbcTemplate.update(sql, parameters);
        
        if (rowsUpdated > 0) {
            // Llamar al procedimiento almacenado calcular_datos_financieros()
            String procedureCall = "CALL calcular_datos_financieros(:idServicio)";
            Map<String, Object> procedureParams = Collections.singletonMap("idServicio", idServicio);
            jdbcTemplate.update(procedureCall, procedureParams);
        }
        
        return rowsUpdated;
    }

    private static class ServicioMapper implements RowMapper<Servicio> {
        @Override
        public Servicio mapRow(ResultSet sr, int rowNum) throws SQLException {

            long id = sr.getInt("id");
            Date fechaIngreso = sr.getDate("fecha_ingreso");
            Date fechaConclusion = sr.getDate("fecha_conclusion");
            String descripcion = sr.getNString("descripcion");
            int horasInvertidas = sr.getInt("horas_invertidas");
            int costoTotalManoDeObra = sr.getInt("costo_total_mano_de_obra");
            int costoTotalFacturado = sr.getInt("costo_total_facturado");
            int porcentajeUtilidad = sr.getInt("porcentaje_utilidad");
            String vehiculo = sr.getString("vehiculo_placa");
            return new Servicio(id, fechaIngreso, fechaConclusion, descripcion, horasInvertidas, costoTotalManoDeObra, costoTotalFacturado, porcentajeUtilidad, vehiculo);


        }
    }
}
