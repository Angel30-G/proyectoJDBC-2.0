package com.codigomorsa.mycrud.services;

import com.codigomorsa.mycrud.model.Vehiculo;
import com.codigomorsa.mycrud.repositories.VehiculoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehiculoService {
    private final VehiculoRepository repository;

    public VehiculoService(VehiculoRepository repository){
        this.repository = repository;
    }

    public List<Vehiculo> getAllVehiculo(){
        return repository.getAllVehiculo();
    }


    public long createVehiculo(Vehiculo newVehiculo) {
        return repository.createVehiculo(newVehiculo);
    }

    public long createVehiculoPlaca(Vehiculo newVehiculo){
        return repository.createVehiculoPlaca(newVehiculo);
    }

    public Vehiculo getVehiculoByPlaca(String placa){
        return repository.getVehiculoByPlaca(placa);
    }

    public boolean existsByPlaca(String placa){
        return repository.existsByPlaca(placa);
    }
}
